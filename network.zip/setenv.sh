
#!/bin/bash
export IMAGE_TAG="x86_64-1.1.0"
export TP_IMAGE_TAG="x86_64-1.0.6"

